* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Benoit Aimont <benoit.aimont@acsone.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Sergio Teruel
  * Ernesto Tejeda
