* Add pivot for tracking events and mail trackings
