To use this module, you need to:

* Add some attachments on an object by creating a new *Log note*

.. figure:: ../static/description/attachment.png
   :alt: Attachment on purchase order

* Then, by sending the object via email, you can select the attachment added earlier

.. figure:: ../static/description/ex_mail_compose_message.png
   :alt: Sends the Purchase Order by email
