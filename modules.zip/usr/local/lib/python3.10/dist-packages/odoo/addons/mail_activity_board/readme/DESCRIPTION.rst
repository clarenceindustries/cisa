This module adds an activity board with form, tree, kanban, calendar, pivot, graph and search views.
