* The module only allows the addition of attachments linked to the object.
