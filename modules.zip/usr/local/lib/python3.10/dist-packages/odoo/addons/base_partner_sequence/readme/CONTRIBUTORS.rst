* Thomas Rehn <thomas.rehn@initos.com>
* Stefan Rijnhart <stefan@therp.nl>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Sandy Carter <sandy.carter@savoirfairelinux.com>
* Laurent Mignon (ACSONE) <laurent.mignon@acsone.eu>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Alexandre Fayolle <alexandre.fayolle@camptocamp.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Akim Juillerat <akim.juillerat@camptocamp.com>
* Cas Vissers <c.vissers@brahoo.nl>
* Quentin Groulard <quentin.groulard@acsone.eu>
* Kevin Khao <kevinkhao@gmail.com>
* Francesco Apruzzese <cescoap@gmail.com>
* Daniel Reis <dreis@opensourceintegrators.com>
* Nikul Chaudhary <nchaudhary@opensourceintegrators.com>
