The development of this module has been financially supported by:

.. image:: https://upload.wikimedia.org/wikipedia/en/3/3b/Aleph_Objects_Logo.png
   :alt: Aleph Objects, Inc
   :target: https://www.alephobjects.com

Images
------

* Enric Tobella (logo)
