This module was written to add the possibility to add attachments located on
the object by sending it by email with the mail compose message wizard
