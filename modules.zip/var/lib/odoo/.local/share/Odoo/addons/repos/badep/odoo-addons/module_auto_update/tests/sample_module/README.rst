Sample module for tests addon_hash module.
