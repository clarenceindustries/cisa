Provide up to date `Fontawesome <http://fontawesome.io/>`_ resources.

Current version: 5.13.0 (the version of this module matches it).
