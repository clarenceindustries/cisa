This module allows you attach several customizable exceptions to your
purchase request in a way that you can filter requests by exceptions type and fix them.

This is especially useful in an scenario for mass purchases requests import, because it's likely some orders have
errors when you import them (like product not found in Odoo, wrong line
format etc.)
