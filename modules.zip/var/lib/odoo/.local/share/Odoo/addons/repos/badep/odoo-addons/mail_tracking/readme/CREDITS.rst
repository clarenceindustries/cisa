Images
------

* Odoo Community Association: `Icon <https://github.com/OCA/maintainer-tools/blob/master/template/module/static/description/icon.svg>`_.
* Thanks to `LlubNek <https://openclipart.org/user-detail/LlubNek>`_ and `Openclipart
  <https://openclipart.org>`_ for `the icon
  <https://openclipart.org/detail/19342/open-envelope>`_.
