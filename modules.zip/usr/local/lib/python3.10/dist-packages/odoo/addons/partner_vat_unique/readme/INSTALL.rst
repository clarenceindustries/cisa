Will not check previous VAT duplicates, so it is recomended make sure there
isn't any duplicated VAT before installation.
