* `SDI <https://www.sdi.es>`_:

  * David Juaneda

* `ForgeFlow <https://www.forgeflow.com>`_:

  * Miquel Raïch (miquel.raich@forgeflow.com)

* `Pesol <https://www.pesol.es>`_:

  * Pedro Gonzalez (pedro.gonzalez@pesol.es)

* `ACSONE SA/NV <https://www.acsone.eu>`_

  * Laurent Mignon <laurent.mignon@acsone.eu>
